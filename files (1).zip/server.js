const app = require('./app');

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`🚀 Student API running on http://localhost:${PORT}`);
  console.log(`📚 Endpoints available at http://localhost:${PORT}/api/students`);
});
