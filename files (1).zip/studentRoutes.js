const express = require('express');
const router = express.Router();
const { validateCreate, validateUpdate } = require('../middleware/validate');
const {
  getAllStudents,
  getStudentById,
  createStudent,
  updateStudent,
  deleteStudent,
} = require('../controllers/studentController');

router.get('/',     getAllStudents);
router.get('/:id',  getStudentById);
router.post('/',    validateCreate, createStudent);
router.put('/:id',  validateUpdate, updateStudent);
router.delete('/:id', deleteStudent);

module.exports = router;
