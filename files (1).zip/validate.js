const VALID_MAJORS = [
  'Computer Science', 'Mathematics', 'Physics', 'Chemistry',
  'Biology', 'Engineering', 'Economics', 'Psychology', 'History', 'Other',
];

/**
 * Validates student fields. Returns an array of error messages.
 * @param {object} data - Request body fields
 * @param {boolean} requireAll - If true, all fields are required (POST). If false, partial update (PUT).
 */
const validateStudent = (data, requireAll = true) => {
  const errors = [];
  const { name, email, age, major, gpa } = data;

  // name
  if (requireAll || name !== undefined) {
    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      errors.push('name must be a string with at least 2 characters');
    }
  }

  // email
  if (requireAll || email !== undefined) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      errors.push('email must be a valid email address');
    }
  }

  // age
  if (requireAll || age !== undefined) {
    if (age === undefined || age === null || !Number.isInteger(age) || age < 16 || age > 100) {
      errors.push('age must be an integer between 16 and 100');
    }
  }

  // major
  if (requireAll || major !== undefined) {
    if (!major || !VALID_MAJORS.includes(major)) {
      errors.push(`major must be one of: ${VALID_MAJORS.join(', ')}`);
    }
  }

  // gpa
  if (requireAll || gpa !== undefined) {
    if (gpa === undefined || gpa === null || typeof gpa !== 'number' || gpa < 0.0 || gpa > 4.0) {
      errors.push('gpa must be a number between 0.0 and 4.0');
    }
  }

  return errors;
};

module.exports = {
  validateCreate: (req, res, next) => {
    const errors = validateStudent(req.body, true);
    if (errors.length > 0) {
      return res.status(400).json({ error: 'Validation failed', details: errors });
    }
    next();
  },

  validateUpdate: (req, res, next) => {
    if (Object.keys(req.body).length === 0) {
      return res.status(400).json({ error: 'Request body must not be empty' });
    }
    const errors = validateStudent(req.body, false);
    if (errors.length > 0) {
      return res.status(400).json({ error: 'Validation failed', details: errors });
    }
    next();
  },
};
