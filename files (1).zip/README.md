# 🎓 Student Management REST API

A Node.js + Express REST API that manages students using an in-memory JavaScript array as the database.

---

## 🚀 Getting Started

```bash
# Install dependencies
npm install

# Start the server
npm start

# Development mode (auto-reload)
npm run dev
```

Server runs at: `http://localhost:3000`

---

## 📁 Project Structure

```
student-api/
├── server.js                   # Entry point
├── app.js                      # Express app & middleware setup
├── package.json
├── db/
│   └── students.js             # In-memory database (JS array)
├── routes/
│   └── studentRoutes.js        # Route definitions
├── controllers/
│   └── studentController.js    # Request handlers / business logic
└── middleware/
    └── validate.js             # Input validation middleware
```

---

## 📡 API Endpoints

### Base URL: `http://localhost:3000/api/students`

| Method   | Endpoint            | Description            |
|----------|---------------------|------------------------|
| `GET`    | `/api/students`     | Get all students       |
| `GET`    | `/api/students/:id` | Get a student by ID    |
| `POST`   | `/api/students`     | Create a new student   |
| `PUT`    | `/api/students/:id` | Update a student       |
| `DELETE` | `/api/students/:id` | Delete a student       |

---

## 🔍 Query Filters (GET /api/students)

| Parameter | Type   | Description                          |
|-----------|--------|--------------------------------------|
| `major`   | string | Filter by major                      |
| `minGpa`  | number | Filter students with GPA ≥ value     |
| `maxGpa`  | number | Filter students with GPA ≤ value     |
| `search`  | string | Search by name or email (partial)    |

**Example:** `GET /api/students?major=Computer Science&minGpa=3.5`

---

## 📦 Student Schema

```json
{
  "id":         1,
  "name":       "Alice Johnson",
  "email":      "alice@example.com",
  "age":        20,
  "major":      "Computer Science",
  "gpa":        3.8,
  "enrolledAt": "2023-09-01T00:00:00.000Z"
}
```

### Valid Majors
`Computer Science`, `Mathematics`, `Physics`, `Chemistry`, `Biology`,
`Engineering`, `Economics`, `Psychology`, `History`, `Other`

---

## 📝 Example Requests

### Create a Student
```bash
curl -X POST http://localhost:3000/api/students \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Diana Prince",
    "email": "diana@example.com",
    "age": 19,
    "major": "Engineering",
    "gpa": 3.7
  }'
```

### Get All Students
```bash
curl http://localhost:3000/api/students
```

### Get Student by ID
```bash
curl http://localhost:3000/api/students/1
```

### Update a Student
```bash
curl -X PUT http://localhost:3000/api/students/1 \
  -H "Content-Type: application/json" \
  -d '{ "gpa": 3.9 }'
```

### Delete a Student
```bash
curl -X DELETE http://localhost:3000/api/students/1
```

---

## ✅ Validation Rules

| Field   | Rules                                          |
|---------|------------------------------------------------|
| `name`  | Required, string, min 2 characters             |
| `email` | Required, valid email format, unique           |
| `age`   | Required, integer between 16–100              |
| `major` | Required, must be one of the valid majors      |
| `gpa`   | Required, number between 0.0–4.0               |

---

## ⚠️ HTTP Status Codes

| Code  | Meaning                         |
|-------|---------------------------------|
| `200` | Success                         |
| `201` | Student created                 |
| `400` | Bad request / validation error  |
| `404` | Student not found               |
| `409` | Email already exists (conflict) |
| `500` | Internal server error           |
