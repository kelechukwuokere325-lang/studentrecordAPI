// In-memory "database" using a JavaScript array
let students = [
  {
    id: 1,
    name: 'Alice Johnson',
    email: 'alice@example.com',
    age: 20,
    major: 'Computer Science',
    gpa: 3.8,
    enrolledAt: '2023-09-01T00:00:00.000Z',
  },
  {
    id: 2,
    name: 'Bob Smith',
    email: 'bob@example.com',
    age: 22,
    major: 'Mathematics',
    gpa: 3.5,
    enrolledAt: '2022-09-01T00:00:00.000Z',
  },
  {
    id: 3,
    name: 'Carol White',
    email: 'carol@example.com',
    age: 21,
    major: 'Physics',
    gpa: 3.9,
    enrolledAt: '2022-09-01T00:00:00.000Z',
  },
];

// Auto-incrementing ID counter
let nextId = 4;

module.exports = {
  getAll: () => students,

  getById: (id) => students.find((s) => s.id === id),

  create: (data) => {
    const student = {
      id: nextId++,
      ...data,
      enrolledAt: new Date().toISOString(),
    };
    students.push(student);
    return student;
  },

  update: (id, data) => {
    const index = students.findIndex((s) => s.id === id);
    if (index === -1) return null;
    students[index] = { ...students[index], ...data, id }; // id is immutable
    return students[index];
  },

  remove: (id) => {
    const index = students.findIndex((s) => s.id === id);
    if (index === -1) return null;
    const [deleted] = students.splice(index, 1);
    return deleted;
  },

  existsByEmail: (email, excludeId = null) =>
    students.some((s) => s.email === email && s.id !== excludeId),
};
