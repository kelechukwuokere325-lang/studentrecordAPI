const db = require('../db/students');

// GET /api/students
const getAllStudents = (req, res) => {
  const { major, minGpa, maxGpa, search } = req.query;

  let students = db.getAll();

  // Optional filters
  if (major) {
    students = students.filter((s) => s.major.toLowerCase() === major.toLowerCase());
  }
  if (minGpa) {
    const min = parseFloat(minGpa);
    if (!isNaN(min)) students = students.filter((s) => s.gpa >= min);
  }
  if (maxGpa) {
    const max = parseFloat(maxGpa);
    if (!isNaN(max)) students = students.filter((s) => s.gpa <= max);
  }
  if (search) {
    const q = search.toLowerCase();
    students = students.filter(
      (s) => s.name.toLowerCase().includes(q) || s.email.toLowerCase().includes(q)
    );
  }

  res.json({
    total: students.length,
    students,
  });
};

// GET /api/students/:id
const getStudentById = (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ error: 'ID must be a number' });

  const student = db.getById(id);
  if (!student) return res.status(404).json({ error: `Student with ID ${id} not found` });

  res.json(student);
};

// POST /api/students
const createStudent = (req, res) => {
  const { name, email, age, major, gpa } = req.body;

  if (db.existsByEmail(email)) {
    return res.status(409).json({ error: `A student with email "${email}" already exists` });
  }

  const student = db.create({ name: name.trim(), email, age, major, gpa });
  res.status(201).json({ message: 'Student created successfully', student });
};

// PUT /api/students/:id
const updateStudent = (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ error: 'ID must be a number' });

  if (!db.getById(id)) {
    return res.status(404).json({ error: `Student with ID ${id} not found` });
  }

  const { name, email, age, major, gpa } = req.body;

  // Check email uniqueness if email is being updated
  if (email && db.existsByEmail(email, id)) {
    return res.status(409).json({ error: `A student with email "${email}" already exists` });
  }

  const updates = {};
  if (name  !== undefined) updates.name  = name.trim();
  if (email !== undefined) updates.email = email;
  if (age   !== undefined) updates.age   = age;
  if (major !== undefined) updates.major = major;
  if (gpa   !== undefined) updates.gpa   = gpa;

  const student = db.update(id, updates);
  res.json({ message: 'Student updated successfully', student });
};

// DELETE /api/students/:id
const deleteStudent = (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ error: 'ID must be a number' });

  const student = db.remove(id);
  if (!student) return res.status(404).json({ error: `Student with ID ${id} not found` });

  res.json({ message: 'Student deleted successfully', student });
};

module.exports = { getAllStudents, getStudentById, createStudent, updateStudent, deleteStudent };
