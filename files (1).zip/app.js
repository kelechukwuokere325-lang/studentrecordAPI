const express = require('express');
const studentRoutes = require('./routes/studentRoutes');

const app = express();

app.use(express.json());

// Root route
app.get('/', (req, res) => {
  res.json({
    message: 'Student Management API',
    version: '1.0.0',
    endpoints: {
      'GET    /api/students':          'Get all students',
      'GET    /api/students/:id':      'Get a student by ID',
      'POST   /api/students':          'Create a new student',
      'PUT    /api/students/:id':      'Update a student by ID',
      'DELETE /api/students/:id':      'Delete a student by ID',
    },
  });
});

// Student routes
app.use('/api/students', studentRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

module.exports = app;
